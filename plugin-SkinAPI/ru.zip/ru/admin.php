<?php

return [
    'title' => 'Настройка Skin API',

    'fields' => [
        'width' => 'Ширина',
        'height' => 'Высота',
        'scale' => 'Максимальный масштаб',
    ],
];
