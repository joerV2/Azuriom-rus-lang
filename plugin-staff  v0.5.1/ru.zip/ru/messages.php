<?php

return [
    'title' => 'Персонал',
    'staff-empty' => 'Список персонала пуст.',
];
