<?php

return [
    'title' => 'FAQ',

    'fields' => [
        'answer' => 'Ответ',
    ],

    'empty' => 'В настоящее время нет вопросов.',
];
